<?php
/*
Plugin Name: newPlugin
Plugin URI: http://myPlugin.com
Description: This is not just a plugin, it symbolizes the strength and weaknesses of an entire generation.
Author: Megha Gupta
Version: 1.7.2
Author URI: http://myPlugin.com
License: GPLv2 or later
*/
function data_table(){

    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
 
    $tablename = $wpdb->prefix."newPlugin";
 
    $sql = "CREATE TABLE $tablename (
      id mediumint(11) NOT NULL AUTO_INCREMENT,
      product_name varchar(300),
      retail_price varchar(200),
      modal varchar(300),
      size varchar(20),
      image varchar(200),
      PRIMARY KEY (id)
    ) $charset_collate;";
 
    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
 dbDelta( $sql );
 
 }
 register_activation_hook( __FILE__, 'data_table' );
 
 // Add menu
 function plugin_menu_page() {
 
    add_menu_page("customPlugin", "customPlugin","manage_options", "newPlugin", "recordlist",plugins_url('/newPLugin/img/two.png'));
 
 }
 add_action("admin_menu", "plugin_menu_page");
 
 function recordList(){
    include "recordlist.php";
 }
 